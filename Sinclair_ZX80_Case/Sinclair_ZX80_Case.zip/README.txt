                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1880449
Sinclair ZX80 Case by alvaroalea is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is part of the project to clone the Sinclair ZX80 8bits computer from 80's by people of the forum http://www.va-de-retro.com/foros/app.php/portal

botton side need to be printer in two part and optionally glued  in normal printers.

For the ribets, search for R2648 in certain chinesse web.

To be printed with support, the STL file also include some aditional supports I need to print it correctly with Cura.

There are aditional parts, for some customizations I made, check the correct parts for your need.


# Print Settings

Printer Brand: Prusa
Printer: Prusa Steel
Rafts: No
Supports: Yes
Resolution: 0.2mm layer, 0.4 nozzle
Infill: 100%

Notes: 
It's need a lot of support, I use Cura, with the zig-zag setting and a separation of 5mm.

# Post-Printing

Remove all the support and enlage the holes with a 2.5mm drill